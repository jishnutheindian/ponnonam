<?php
if ($_SERVER['HTTPS'] != "on") {
    $url = "https://". $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
    header("Location: $url");
    exit;
}
session_start();
require_once 'class.user.php';
$user_home = new USER();

if(!$user_home->is_logged_in())
{
	$user_home->redirect('inup.php');
}
$email=$_GET['id'];
echo'<div class="modal-header"><h1 style="align:right">'.$email.'</h1>  
          <h2 class="modal-title">Upload your profile picture</h2>
        </div>
        <div class="modal-body">
<form action="upload.php?id='.$email.'&spec=propic" method="post" enctype="multipart/form-data">    <input type="file" name="fileToUpload" id="fileToUpload">
    <input type="submit" value="Upload Image" name="submit" onclick="show()">
</form>
</div>';
?>