<?php
if ($_SERVER['HTTPS'] != "on") {
    $url = "https://". $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
    header("Location: $url");
    exit;
}
session_start();
require_once 'class.user.php';
$user_home = new USER();
$uid=$_SESSION["id"];
if(!$user_home->is_logged_in())
{
	$user_home->redirect('timeline.php');
}
$spec=$_GET["spec"];
$servername = "localhost";
$username = "zerodollar";
$password = "jishnu9345";
$dbname = "pecmalluz";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
$name = $_GET["id"];
$old;
if($spec=="propic")
{$old="oldpro";
   $comment="Updated my Profile Picture";
}
else
{$old="oldwall"; 
   $comment="Updated my Wall Picture";
}
$x=$_SESSION["id"];
$y=$_SESSION["usermail"];
$url='//pecmalluz.com/timeline.php';
$target_dir = "images/";
$filename=basename($_FILES["fileToUpload"]["name"]);
$target_file = $target_dir .$filename;
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
       // ////echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        ////echo "File is not an image.";
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file)) {
    ////echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
/*if ($_FILES["fileToUpload"]["size"] > 500000) {
    ////echo "Sorry, your file is too large.";
    $uploadOk = 0;
	
}*/
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" && $imageFileType != "JPG" && $imageFileType != "PNG" && $imageFileType != "JPEG" && $imageFileType != "GIF") {
    ////echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    ////echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {

$file = "SELECT imagename FROM images WHERE userEmail='$name' AND spec='$spec' ";
$f = "DELETE FROM images WHERE userEmail='$name' AND imagename='avatar_2x.png' ";
$sl="UPDATE images SET spec='$old',uid='$uid' WHERE userEmail='$name' AND spec='$spec'";
$result= $conn->query($file);

if (mysqli_num_rows($result) > 0) {
if ($conn->query($sl) == TRUE) {
$conn->query($f);
    ////echo "image adress added successfully";
	header("Location: $url");
} else {
    ////echo "Error: " . $sl . "<br>" . $conn->error;
}


     }

    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        ////echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO images(userEmail,imagename,spec,imagetype,uid) VALUES('$name','$filename','$spec','$imageFileType','$uid')";

if ($conn->query($sql) == TRUE) {
    ////echo "image adress added successfully";
 
    $sql = "INSERT INTO timeline(usermail,imagesrc,post,uid) VALUES('$y','$filename','$comment','$x')";
    $conn->query($sql);
	header("Location: $url");
} else {
    ////echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

		
	} else {
		
        ////echo "Sorry, there was an error uploading your file.";
    }
}
?> 