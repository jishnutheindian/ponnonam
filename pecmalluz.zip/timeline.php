<?php
if ($_SERVER['HTTPS'] != "on") {
    $url = "https://". $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
    header("Location: $url");
    exit;
}
session_start();
require_once 'class.user.php';
$user_home = new USER();

if(!$user_home->is_logged_in())
{
	$user_home->redirect('inup.php');
}

$stmt = $user_home->runQuery("SELECT * FROM users WHERE userEmail=:uid");
$stmt->execute(array(":uid"=>$_SESSION['userSession']));
$row = $stmt->fetch(PDO::FETCH_ASSOC);
$_SESSION["id"] = $row['userID'];
$_SESSION["username"]= $row['userName'];
$_SESSION["usermail"]= $row['userEmail'];

?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<title>InProlife</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="//pecmalluz.com/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript"> var infolinks_pid = 2884254; var infolinks_wsid = 0; </script> <script type="text/javascript" src="//resources.infolinks.com/js/infolinks_main.js"></script>
<script type="text/javascript" src="//pecmalluz.com/js/jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="//pecmalluz.com/js/script.js"></script>
<script type="text/javascript" src="//pecmalluz.com/js/cufon-yui.js"></script>
<script type="text/javascript" src="//pecmalluz.com/js/arial.js"></script>
<script type="text/javascript" src="//pecmalluz.com/js/cuf_run.js"></script>
<!--  Latest compiled and minified CSS -->
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

<!-- Latest compiled JavaScript--> 
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

 
<script>
window.onload = function() {
    var canvas = document.getElementById("canvas");
    var ctx = canvas.getContext("2d");
    var img = document.getElementById("canvas");
    ctx.drawImage(img, 10, 10);
 
    var canva = document.getElementById("vas");
    var ct = canva.getContext("2d");
    var im= document.getElementById("vas");
    ct.drawImage(im, 10, 10);
};

</script>
<script>
<?php echo 'var email="'.$row['userEmail'].'";';
	?>

	function showHint(str) {
    if (str.length == 0) {
        document.getElementById("txtHint").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("txtHint").innerHTML = this.responseText;
            }
        };
        xmlhttp.open("GET", "getfriends.php?q=" + str, true);
        xmlhttp.send();
    }
}
function show()
{  $("#loadingDiv").show();
  }

$(document).ready(function(){

  $('#imgupload').hide();
  $('#OpenImgUpload').click(function(){ $('#imgupload').trigger('click'); });

$("#loadingDiv").hide();
var l="loadtimeline.php?id=";
                 var man=l+email;
				 
		$("#timeline").load(man);
		

$("#s2").click(function(){
       
    var k6="about.php?id=";
                 var n6=k6+email;
				 
				 $("#m").load(n6);
				   $("#myModal").modal();
                 
		
    });
   $("#pics").hide();
	$(".up").hide();
    $("#canvas").click(function(){
	 var k="proup.php?id=";
                 var n=k+email;
				 
				 $("#m").load(n);
				  
                 $("#myModal").modal();
	
			
    });
	$("#vas").click(function(){
       
    var k1="wallup.php?id=";
                 var n1=k1+email;
				 
				 $("#m").load(n1);
				  
                 $("#myModal").modal();
		
    });
	$("#search").click(function(){
       
    
				  
                 $("#searchmodal").modal();
		
    });
	$("#cm").click(function(){
       
    var k1="friends.php?id=";
                 var n1=k1+email;
				 
				 $("#m").load(n1);
				   $("#myModal").modal();
                 
		
    });
	$("#rp").click(function(){
       
    var k1="resetpass.php?id=";
                 var n1=k1+email;
				 
				 $("#m").load(n1);
				  
                 $("#myModal").modal();
		
    });

	$("#album").click(function(){
                 var k1="album.php?id=";
                 var n1=k1+email;
			
				 $("#m").load(n1);
				  
                 $("#myModal").modal();  
     
    });


 $("#canvas").mouseenter(function(){
       $(this).fadeTo("slow", 0.7);
	    });
		  $("#vas").mouseenter(function(){
       $(this).fadeTo("slow", 0.7);
	    });
$("#canvas").mouseleave(function(){
  $(this).fadeTo("slow",1.0);
}); 
	$("#vas").mouseleave(function(){
  $(this).fadeTo("slow",1.0);

});});


</script>
<style>
#loadingDiv{
  position:fixed;
  top:0px;
  right:0px;
  width:100%;
  height:100%;
  background-color:#666;
  background-image:url('images/loading.gif');
  background-repeat:no-repeat;
  background-position:center;
  background-attachment: fixed;
  z-index:10000000;
  opacity: 0.4;
  filter: alpha(opacity=40); /* For IE8 and earlier */
}
</style>
</head>
<body>


<div class="main">
  <div class="main_resize">
   
     

      
	  <!-- nav bar-->
	  <nav class="navbar navbar-default navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <img class="navbar-brand" src="images/quickearn.png" href="#">
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a  href="index.php">Home</a></li>
        <li><a  id="s2">About</a></li>
        <li><a  href="#s3">Projects</a></li>
        <li><a  href="#s4">Contact</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
            			 <li><a id="search"><span class="glyphicon glyphicon-search"></span> search</a></li>

			 <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
        
      </ul>
    </div>
  </div>
</nav>
     
        
      <div class="me" style="position: relative; left: 0; top: 0px;">
     <div class="bgc" id="134">
	  
	  <?php
	  $servername = "localhost";
      $username = "zerodollar";
$password = "jishnu9345";
$dbname = "pecmalluz";
	  $conn = new mysqli($servername, $username, $password, $dbname);
	  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
        }
      $fi=$f=" ";
$mail=$row['userEmail'];
$file = "SELECT imagename FROM images WHERE userEmail='$mail' AND spec='propic' ";
$fwall="SELECT imagename FROM images WHERE userEmail='$mail' AND spec='wallpic' ";
$result= $conn->query($file);
if (mysqli_num_rows($result) > 0) {
 while($r = $result->fetch_assoc()) {
        $f=$r["imagename"];
         $_SESSION["imagename"]=$f;
     }
}
$rwall= $conn->query($fwall);
if (mysqli_num_rows($rwall) > 0) {
 while($rw = $rwall->fetch_assoc()) {
        $fi=$rw["imagename"];
     }
}

echo '<img src="images/',$fi,'" id="vas" class="hbg" width="923" height="291" alt=""/><img src="images/',  $f;
	



	  ?>" class="propic" id="canvas" alt=""/>
	  <h8><?php echo $row['userName']; ?></h8>
	  <!---->
	  </div></div>



    <div class="content">
      <div class="content_bg">
        <div class="mainbar">
		<!--timeline-->
		<form action="updatetimeline.php?id=<?php echo $row['userEmail'];
		?>"enctype="multipart/form-data" method="post">  
    <br>
	<span class="glyphicon glyphicon-share" style="color:blue;"></span> Share your memmories here...
  <br><br>
  
 <textarea name="comment" id="comment" rows="1" cols="50"></textarea>
<input type="submit" class="btn btn-info" value="share" name="submit" onclick="show()">

<input type="file" id="imgupload" name="fileToUpload"/> 
<img src="images/pin.png" id="OpenImgUpload" width="50px" height="50px">
</form>
<!--end-timeline-->
<br>

 <h2><span>Timeline</span></h2>
          <div id="timeline">
		  </div>
        </div>
        <div class="sidebar">
          <div class="gadget">
            <h2 class="star"><span> Personal</span> Menu</h2>
            <div class="clr"></div>
            <ul class="sb_menu">
              <li class="active"><a>Home</a></li>
              <li ><a href="profile.php?id=<?php
              echo $_SESSION["usermail"].'&name='.$_SESSION["username"];
              
               
              ?>">Profile</a></li>
           <li>
		   <div id="album">Album
		   <div></li>
		  
              <div id="cm"><li>community</li></div>
              <div id="rp"> <li>reset password</li></div>
              <li><a href="#">Archives</a></li>
              
            </ul>
          </div>
         
 <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
<!-- Modal content-->
      <div class="modal-content">
      <div id="m">

	  </div>
        <div class="modal-footer">
          <br>
		  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div></div></div>

	  <!-- search modal -->
  <div class="modal fade" id="searchmodal" role="dialog">
    <div class="modal-dialog">
<!-- Modal content-->
      <div class="modal-content">
     <div class="modal-header"><h3 style="align:right"><form>
<input type="text" onkeyup="showHint(this.value)">
</form></h3>  
          <h4 class="modal-title">Search inside Community</h4>
        </div>
        <div class="modal-body" id="txtHint">

</div>
        <div class="modal-footer">
          <br>
		  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div></div></div>



<div id="loadingDiv">
    <div>
        <h7>Please wait...</h7>
    </div>
</div>
</body>

</html>